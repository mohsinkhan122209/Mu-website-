📘 README.txt — Expense Tracker Project

Project Title: Expense & Budget Tracker  
Submitted by: Mohsin Khan  
Roll No: CU-5377-2024  
Submission Type: Individual  
Marks Weightage: 100 Marks  

---

📌 Project Overview:
This is a PHP-based Expense and Budget Tracker System designed to help users manage their income, budget limits, and track expenses across different categories.

---

🧠 Key Features:
- User authentication (Admin login)
- Dashboard for overview
- Add/manage budget categories
- Add/manage expenses
- Budget vs expense reports
- Category maintenance
- System info panel

---

⚙️ Requirements:
- XAMPP or WAMP (Apache + MySQL)
- Web browser (Chrome, Firefox, etc.)
- PHP 7.0+ recommended

---

🚀 Setup Instructions:
1. Extract the project folder Expense_Tracker_Project_Final.zip.
2. Copy the folder into your htdocs (XAMPP) or www (WAMP) directory.
3. Open phpMyAdmin in your browser:
   http://localhost/phpmyadmin
4. Create a new database named:
   expense_budget_db
5. Click Import, and upload the SQL file:
   database/expense_budget_db.sql
6. Start Apache and MySQL in XAMPP/WAMP.
7. Visit your project in browser:
   http://localhost/Expense_Tracker_Project_Final/

---

🔑 Default Admin Login:
- Username: admin  
- Password: admin123  
(If these don’t work, reset manually from database > users table)

---

📁 Project Structure:
- index.php: Main entry
- admin/: Admin panel
- admin/budget/: Budget management
- admin/expense/: Expense management
- admin/reports/: Reporting tools
- admin/user/: User list
- database/expense_budget_db.sql: SQL database file

---

✅ Final Checklist Before Submission:
- [x] PHP Files ✅  
- [x] Database SQL File ✅  
- [x] README File ✅  
- [x] Screenshot (optional but included) ✅  
- [x] Organized Folders ✅  
- [x] Tested on Localhost ✅  

---

📞 Contact (if needed):
Mohsin Khan  
Roll No: CU-5377-2024
